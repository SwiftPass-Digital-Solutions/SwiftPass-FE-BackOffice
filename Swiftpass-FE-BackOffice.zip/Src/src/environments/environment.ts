export const environment = {
    apiUrl: 'https://swiftpass-backend.onrender.com/api'
};