import { Component } from '@angular/core';

@Component({
  selector: 'app-business-info',
  imports: [],
  templateUrl: './business-info.component.html',
  styleUrl: './business-info.component.scss'
})
export class BusinessInfoComponent {

}
