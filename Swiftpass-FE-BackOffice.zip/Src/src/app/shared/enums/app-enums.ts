export enum UserType {
    SwiftPassUser,
    BackOffice,
    Business
}